﻿using System;
using System.Collections.Generic;
using System.Text;
using Gallio.Framework;
using MbUnit.Framework;
using MbUnit.Framework.ContractVerifiers;

namespace ImageResizer.Tests {
    [TestFixture]
    public class TestPolygonMath {
        [Test]
        public void Test() {
            //
            // TODO: Add test logic here
            //
        }
    }
}

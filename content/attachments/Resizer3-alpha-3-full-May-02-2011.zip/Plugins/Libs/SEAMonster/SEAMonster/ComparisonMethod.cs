namespace SEAMonster
{
    public enum ComparisonMethod { Total, Average, DiffBias };
}

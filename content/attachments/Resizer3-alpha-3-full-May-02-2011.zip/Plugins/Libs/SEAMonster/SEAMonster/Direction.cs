namespace SEAMonster
{
    public enum Direction { Vertical, Horizontal, Optimal };
}

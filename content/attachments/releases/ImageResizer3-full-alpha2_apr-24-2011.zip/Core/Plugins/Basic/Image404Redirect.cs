﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ImageResizer.Plugins.Basic {
    /// <summary>
    /// Stub class, plan to implement later
    /// </summary>
    public class Image404Redirect {

    }
}

﻿/* Copyright (c) 2011 Nathanael Jones. See license.txt for your rights. */
using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace ImageResizer.Plugins.DiskCache {
  
    /// <summary>
    /// Provides thread-safe access to the index of the disk cache
    /// </summary>
    public class CacheIndex : CachedFolder {
        public CacheIndex(){
        }






        
    }
}

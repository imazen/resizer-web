In order to compile the solution, you must redirect the references to Endogine.dll (both projects) and Endogine.Editors.dll (Psd project only). Remove the references, then add them again by browsing and selecting them from the Dlls folder.
This is because I use the actual output dlls from those projects while developing.

Sorry for the inconvenience!